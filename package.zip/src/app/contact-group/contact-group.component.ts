import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { AngularFireDatabase } from 'angularfire2/database';
import { Subscriber } from 'rxjs';
import { FirebaseApp } from 'angularfire2';
import { environment } from '../../environments/environment.prod';

@Component({
  selector: 'app-contact-group',
  templateUrl: './contact-group.component.html',
  styleUrls: ['./contact-group.component.css']
})
export class ContactGroupComponent implements OnInit {

  userId : any;
  contactGroupArray : any = [];
  groupsPresent : boolean = false;
  contactGroupForm : FormGroup;
  groupName: FormControl;
  groupDescription: FormControl;

  constructor(public db: AngularFireDatabase,private fb: FormBuilder) { }

  ngOnInit() {
    this.userId = localStorage.getItem("userId");
    this.createControls();
    this.createForm();
    this.db.list("/contactInformation/"+this.userId).valueChanges().subscribe(data=>{
      console.log("DATA::::",data);
      if(data.length != 0){
        this.groupsPresent = true;
        this.contactGroupArray = data[0];
        //console.log(this.contactGroupArray);
      }
    });
  }

  addContactGroup(){
    this.contactGroupArray.push(this.contactGroupForm.value);
    let updateInfo = this.db.object('/contactInformation/'+this.userId+'/ContactGroups').set(this.contactGroupArray);
  }

  createControls() {
    this.groupName = new FormControl('', [
      Validators.required,
      Validators.pattern('^[a-zA-Z ]+$')
    ])
    this.groupDescription = new FormControl('', [
      Validators.required,
      Validators.pattern('^[a-zA-Z ]+$')
    ])
  }

  createForm() {
    this.contactGroupForm = new FormGroup({
      groupName: this.groupName,
      groupDescription: this.groupDescription
    });
  }
}
