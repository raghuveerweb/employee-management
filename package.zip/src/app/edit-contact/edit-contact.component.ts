import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { AngularFireDatabase } from 'angularfire2/database';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-edit-contact',
  templateUrl: './edit-contact.component.html',
  styleUrls: ['./edit-contact.component.css']
})
export class EditContactComponent implements OnInit {

  userId : any;
  contactArray : any = [];
  contactsPresent : boolean = false;
  contactForm : FormGroup;
  typeSplit : any = [];
  phone: FormControl;
  name : FormControl;
 
  constructor(public db: AngularFireDatabase,private fb: FormBuilder, private activatedRoute : ActivatedRoute) { }

  ngOnInit() {
    this.userId = localStorage.getItem("userId");
    this.createControls();
    this.createForm();
    
    this.fetchContacts();
    this.setValues();
  }
  
  fetchContacts(){
    let url;
    //alert(this.activatedRoute.snapshot.params["type"]);
    let type = this.activatedRoute.snapshot.params["type"];
    if(type == "contact"){
      url = "/contactInformation/"+this.userId+'/contacts';
    }else{
      this.typeSplit = type.split("-");
      url = "/contactInformation/"+this.userId+'/ContactGroups';
    }
    
    this.db.list(url).valueChanges().subscribe(data=>{
      console.log("DATA::::",data);
      if(data.length != 0){
        if(this.typeSplit.length == 0){
          this.contactArray = data;
        }else{
          this.contactArray = data[0];
        }
        console.log(this.contactArray);
      }
    });
  }

  setValues(){
    //alert(this.activatedRoute.snapshot.params["name"]);
    this.name.setValue(this.activatedRoute.snapshot.params["name"]);
    this.phone.setValue(this.activatedRoute.snapshot.params["phone"]);
  }

  addContact(){
    this.contactArray.push(this.contactForm.value);
    console.log(this.contactArray);
    let updateInfo = this.db.object('/contactInformation/'+this.userId+'/contacts').set(this.contactArray);
  }

  createControls() {
    this.name = new FormControl('', [
      Validators.required,
      Validators.pattern('^[a-zA-Z ]+$')
    ])
    this.phone = new FormControl('', [
      Validators.required,
      Validators.pattern('^[0-9]+$')
    ])
  }

  createForm() {
    this.contactForm = new FormGroup({
      name: this.name,
      phone: this.phone
    });
  }
}
