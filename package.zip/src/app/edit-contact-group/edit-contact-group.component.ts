import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatPaginator, MatSort } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { AngularFireDatabase } from 'angularfire2/database';

@Component({
  selector: 'app-edit-contact-group',
  templateUrl: './edit-contact-group.component.html',
  styleUrls: ['./edit-contact-group.component.css']
})
export class EditContactGroupComponent implements OnInit {

  userContacts : any = [];
  userId : any;

  displayedColumns: string[] = ['name', 'phone', 'actions'];

  dataSource = new MatTableDataSource<PeriodicElement>(this.userContacts);

  @ViewChild(MatPaginator,) paginator: MatPaginator;

  @ViewChild(MatSort) sort: MatSort;

  getIndexOfelement(arrayTocheck, attr, value) {
    for (var i = 0; i < arrayTocheck.length; i += 1) {
      if (arrayTocheck[i][attr] === value) {
        return i;
      }
    }
    return -1;
  }

  constructor(private router: Router, private activatedRoute: ActivatedRoute, public db: AngularFireDatabase) { }

  ngOnInit() {
    this.userId = localStorage.getItem("userId");
    this.db.list("/contactInformation/"+this.userId).valueChanges().subscribe(data=>{
      console.log("DATA at value change::::",data);
      this.dataSource = new MatTableDataSource<PeriodicElement>(this.userContacts);
      this.dataSource.paginator = this.paginator;
      
      if(data.length != 0){
        let groupNameIndex = this.getIndexOfelement(data[0],'groupName',this.activatedRoute.snapshot.queryParams["id"]);
        if(data[0][groupNameIndex].contacts.length != 0){
          this.userContacts = data[0][groupNameIndex].contacts;
        }
      }
    });
  }

}
export interface PeriodicElement {
  name: string;
  phone: number
}
