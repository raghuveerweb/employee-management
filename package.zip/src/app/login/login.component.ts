import { Component, OnInit } from '@angular/core';
import { AngularFireDatabase } from 'angularfire2/database';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { AuthService } from '../core/auth.service';

import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm : FormGroup;
  
  username : FormControl;
  password : FormControl 

  constructor(public db: AngularFireDatabase,private fb: FormBuilder, private auth : AuthService, private router : Router) { }

  ngOnInit() {
    this.createControls();
    this.createForm();
  }

  login(){
    this.auth.emailLogin(this.username.value, this.password.value).then(
      (data: any) => {
        if(data.code){
          //show error message
        }else{
          localStorage.setItem('userId',data.uid);
          localStorage.setItem('email',this.username.value);

          this.router.navigateByUrl("/app/dashboard");
        }
      }
    )
  }

  createControls() {
    this.username = new FormControl('', [
      Validators.required
    ])
    this.password = new FormControl('', [
      Validators.required
    ])
    
  }

  createForm() {
    this.loginForm = new FormGroup({
      username: this.username,
      password: this.password
    });
  }

}
